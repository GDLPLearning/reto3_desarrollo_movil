package usa.cicloiv.mireto3.Vista;

import android.Manifest;
import android.app.AlertDialog;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.database.Cursor;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.drawable.BitmapDrawable;
import android.net.Uri;
import android.os.Bundle;
import android.text.InputType;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;

import com.google.android.gms.maps.CameraUpdateFactory;
import com.google.android.gms.maps.GoogleMap;
import com.google.android.gms.maps.OnMapReadyCallback;
import com.google.android.gms.maps.model.LatLng;
import com.google.android.gms.maps.model.MarkerOptions;
import com.google.android.material.snackbar.Snackbar;

import java.io.ByteArrayOutputStream;
import java.io.FileNotFoundException;
import java.io.InputStream;

import usa.cicloiv.mireto3.Modelo.BaseDatos.DBHelper;
import usa.cicloiv.mireto3.R;
import usa.cicloiv.mireto3.databinding.SucursalesFormBinding;

public class FormSucursales extends AppCompatActivity implements OnMapReadyCallback {
    private final int REQUEST_CODE_GALLERY = 999;
    private TextView tv2Titulo;
    private EditText campo11, campo22, campo33, edit2Id;
    private Button btn2Choose, btn2Insertar, btn2Eliminar, btn2Consultar, btn2Actualizar;
    private ImageView img2Selected;
    String name = "";
    private DBHelper dbHelper;
    private SucursalesFormBinding binding;


    String campo11Insert;
    String campo22Insert;
    String campo33Insert;
    byte[] image2Insert;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        try {
            setContentView(R.layout.sucursales_form);

            binding = SucursalesFormBinding.inflate(getLayoutInflater());
            setContentView(binding.getRoot());

            tv2Titulo = (TextView) findViewById(R.id.tv2Titulo);
            Intent intent = getIntent();
            name = intent.getStringExtra("name");
            edit2Id = (EditText) findViewById(R.id.edit2IdItem);
            campo11 = (EditText) findViewById(R.id.edit2Campo1);
            campo22 = (EditText) findViewById(R.id.edit2Campo2);
            campo33 = (EditText) findViewById(R.id.edit2Campo3);
            btn2Choose = (Button) findViewById(R.id.btn2Choose);
            btn2Insertar = (Button) findViewById(R.id.btn2Insertar);
            btn2Consultar = (Button) findViewById(R.id.btn2Consultar);
            btn2Eliminar = (Button) findViewById(R.id.btn2Eliminar);
            btn2Actualizar = (Button) findViewById(R.id.btn2Actualizar);
            img2Selected = (ImageView) findViewById(R.id.img2Selected);
            dbHelper = new DBHelper(getApplicationContext());

            tv2Titulo.setText(name);
            if(name.equals("PRODUCTOS")){
                campo11.setHint("Escriba nombre");
                campo22.setHint("Escriba Descripción");
                campo33.setHint("Precio");
            }else if(name.equals("SERVICIOS")){
                campo11.setHint("Escriba nombre");
                campo22.setHint("Escriba Descripción");
                campo33.setHint("Descripcion2");
            }else if(name.equals("SUCURSALES")){
                campo11.setHint("Escriba nombre");
                campo22.setHint("Escriba Descripción");
                campo33.setHint("Ubicacion");
                campo33.setInputType(InputType.TYPE_CLASS_TEXT);
            }

            btn2Choose.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    ActivityCompat.requestPermissions(
                            FormSucursales.this,
                            new String[]{Manifest.permission.READ_EXTERNAL_STORAGE},
                            REQUEST_CODE_GALLERY
                    );
                }
            });

            btn2Insertar.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    try {
                        llenarCampos();
                        dbHelper.insertData(campo11Insert, campo22Insert, campo33Insert, image2Insert, name);
                        limpiarCampos();
                        Toast.makeText(getApplicationContext(), "Cargue Exitoso!", Toast.LENGTH_SHORT).show();
                    }catch (Exception e){
                        Toast.makeText(getApplicationContext(), e.toString(), Toast.LENGTH_LONG).show();
                    }
                }
            });
            btn2Consultar.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    Cursor cursor = dbHelper.getDataById(name, edit2Id.getText().toString().trim());
                    while (cursor.moveToNext()){
                        campo11.setText(cursor.getString(1));
                        campo22.setText(cursor.getString(2));
                        campo33.setText(cursor.getString(3));
                        byte[] img = cursor.getBlob(4);
                        Bitmap bitmap = BitmapFactory.decodeByteArray(img,0,img.length);
                        img2Selected.setImageBitmap(bitmap);
                    }
                }
            });
            btn2Eliminar.setOnClickListener(new View.OnClickListener() {
                View view = findViewById(R.id.linear2LayoutForm);
                @Override
                public void onClick(View view) {
                    AlertDialog.Builder builder = new AlertDialog.Builder(view.getContext());
                    builder.setTitle("Delete")
                            .setMessage("¿Quiere eliminar el item?")
                            .setPositiveButton("Ok", new DialogInterface.OnClickListener() {
                                @Override
                                public void onClick(DialogInterface dialog, int which) {
                                    dbHelper.deleteDataById(name,edit2Id.getText().toString().trim());
                                    Snackbar.make(view, "Eliminado", Snackbar.LENGTH_SHORT).show();
                                }
                            })

                            .setNegativeButton("Cancel", new DialogInterface.OnClickListener() {
                                @Override
                                public void onClick(DialogInterface dialog, int which) {
                                    Snackbar.make(view, "No se Elimino", Snackbar.LENGTH_SHORT).show();
                                }
                            })
                            .setCancelable(false);
                    AlertDialog alert = builder.create();
                    alert.show();
                    limpiarCampos();
                }
            });


        /*btn2Eliminar.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                View view = findViewById(R.id.linear2LayoutForm);
                dbHelper.deleteDataById(name,edit2Id.getText().toString().trim());
                limpiarCampos();
                Snackbar.make(view, "Eliminado", Snackbar.LENGTH_SHORT).show();
            }
        });*/
            btn2Actualizar.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    llenarCampos();
                    try{
                        dbHelper.updateSucursalById(
                                name,
                                edit2Id.getText().toString().toString(),
                                campo11Insert,
                                campo22Insert,
                                campo33Insert,
                                image2Insert
                        );
                    }catch (Exception e){
                        Toast.makeText(getApplicationContext(), e.toString(), Toast.LENGTH_SHORT).show();
                    }

                }
            });
        }catch (Exception e){
            Log.w("Error ->", e.toString());
        }



    }

    public byte[] imageViewToByte(ImageView imageView){
        Bitmap bitmap = ((BitmapDrawable) imageView.getDrawable()).getBitmap();
        ByteArrayOutputStream stream = new ByteArrayOutputStream();
        bitmap.compress(Bitmap.CompressFormat.PNG, 100, stream);
        byte[] byteArray = stream.toByteArray();
        return byteArray;
    }

    public void llenarCampos(){
        campo11Insert = campo11.getText().toString().trim();
        campo22Insert = campo22.getText().toString().trim();
        campo33Insert = campo33.getText().toString().trim();
        image2Insert = imageViewToByte(img2Selected);
    }

    public void limpiarCampos(){
        campo11.setText("");
        campo22.setText("");
        campo33.setText("");
        img2Selected.setImageResource(R.mipmap.ic_launcher);
    }

    @Override
    public void onRequestPermissionsResult(int requestCode, @NonNull String[] permissions, @NonNull int[] grantResults) {
        if(requestCode == REQUEST_CODE_GALLERY){
            if(grantResults.length > 0 && grantResults[0] == PackageManager.PERMISSION_GRANTED){
                Intent intent = new Intent(Intent.ACTION_PICK);
                intent.setType("image/*");
                startActivityForResult(intent, REQUEST_CODE_GALLERY);
            }else{
                Toast.makeText(getApplicationContext(), "Sin Permisos", Toast.LENGTH_SHORT).show();
            }
        }
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, @Nullable Intent data) {
        if(requestCode == REQUEST_CODE_GALLERY && resultCode == RESULT_OK && data != null){
            Uri uri = data.getData();
            try {
                InputStream inputStream = getContentResolver().openInputStream(uri);
                Bitmap bitmap = BitmapFactory.decodeStream(inputStream);
                img2Selected.setImageBitmap(bitmap);
            }catch (FileNotFoundException e){
                e.printStackTrace();
            }
        }
        super.onActivityResult(requestCode, resultCode, data);
    }

   @Override
    public void onMapReady(GoogleMap googleMap) {
        try {
            LatLng colombia = new LatLng(5, -76);
            googleMap.moveCamera(CameraUpdateFactory.newLatLngZoom(colombia,6));

            googleMap.setOnMapClickListener(new GoogleMap.OnMapClickListener() {
                @Override
                public void onMapClick(@NonNull LatLng latLng) {
                    MarkerOptions markerOptions = new MarkerOptions();
                    markerOptions.position(latLng);
                    googleMap.clear();
                    googleMap.animateCamera(CameraUpdateFactory.newLatLng(latLng));
                    googleMap.addMarker(markerOptions);
                    Double lat = latLng.latitude;
                    Double lon = latLng.longitude;
                    campo33.setText(lat + "," + lon);
                }
            });
        }catch (Exception e){
            Log.w("Error ->", e.toString());
        }

    }
}